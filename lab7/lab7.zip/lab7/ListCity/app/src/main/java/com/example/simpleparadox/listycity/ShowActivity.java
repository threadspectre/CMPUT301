package com.example.simpleparadox.listycity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ShowActivity extends AppCompatActivity {

    TextView cityItemTextView;
    String cityItem;
    EditText newName;
    LinearLayout nameField;
    ArrayAdapter<String> cityAdapter;
    ArrayList<String> dataList;

    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        dataList = new ArrayList<>();

        backButton=findViewById(R.id.button_back);

        cityItemTextView = findViewById(R.id.textView_city);

        //dataList.addAll(Arrays.asList(cities));



        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            cityItem = extras.getString("key");
        }

        cityItemTextView.setText(cityItem);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
